import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

interface Employee {
  name: string;
  username: string;
  city: string;
  website: string;
  email: string;
  contact: number;
}

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  employees: Employee[] = [];

  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.fetchEmployees();
  }

  fetchEmployees() {
    // Fetch data from API
    this.http.get<Employee[]>('https://jsonplaceholder.typicode.com/users').subscribe((apiData: Employee[]) => {
      this.employees = apiData;

     
      const localStorageData = localStorage.getItem('employees');
      if (localStorageData) {
        const localStorageEmployees: Employee[] = JSON.parse(localStorageData);
        
        this.employees = this.employees.concat(localStorageEmployees);
      }
    });
  }
}
