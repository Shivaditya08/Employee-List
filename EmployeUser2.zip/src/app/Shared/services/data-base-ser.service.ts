import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataBaseSerService {
 
  constructor(private _http:HttpClient) { }
  
   //get request
  fetchData(){
    return this._http.get("http://localhost:8888/employee")
  }

  deleteEmployee(id:any){
    return this._http.delete(`http://localhost:8888/employee/${id}`)
  }
  addEmployee(data:any){
    return this._http.post(`http://localhost:8888/employee`,data);
  }

  //get request for single data
  getSingleDataRequest(id:any){
    return this._http.get(`http://localhost:8888/employee/${id}`)
  }
 
  //put request
  updateEmployee(id:any,data:any){
    return this._http.put(`http://localhost:8888/employee/${id}`,data);
  }

}
