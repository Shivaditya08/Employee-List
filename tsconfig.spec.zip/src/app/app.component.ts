import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';


import { FooterComponent } from './footer/footer.component';



@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,FormsModule,FooterComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})

export class AppComponent {
  title = 'angproject';
  myName="Totan Hazra";
  myData="Gauti";
  welcome(Shivaditya:string){
    window.alert(`My Name is ${Shivaditya}  and I welcome you all `)
}
 
greeting(){
  window.alert("Namaste London")
}
greet(yourname:string){
  window.alert (`My Name is `)
}
}
 
