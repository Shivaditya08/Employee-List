import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyservicesService {

  constructor() { }

  
emp:any[]=[
      {empId:101,empName:"Devdutt",empPost:"Batsman",address:"Delhi"},
      {empId:102,empName:"Sanjay",empPost:"Keeper",address:"Jaipur"},
      {empId:103,empName:"Lokesh",empPost:"Coach",address:"Trivandram"},
      {empId:104,empName:"Dravid",empPost:"Bowler",address:"Kashmir"},
      {empId:105,empName:"Yash",empPost:"Manager",address:"Mumbai"},
      {empId:106,empName:"Tilak",empPost:"ASE",address:"Rajkot"}
    ]
}
