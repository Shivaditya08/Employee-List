// import { CommonModule } from '@angular/common';
// import { Component } from '@angular/core';

 
// import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators ,ValidatorFn,AbstractControl} from '@angular/forms';

// @Component({
//   selector: 'app-student-register',
//   standalone: true,
//   imports: [CommonModule,ReactiveFormsModule],
//   templateUrl: './student-register.component.html',
//   styleUrl: './student-register.component.css'
// })
// export class StudentregisterComponent {
//   studentForm:any;
 
//   constructor(private fb:FormBuilder){
 
//   }
//   ngOnInit(){
//     this.studentForm=this.fb.group({
//       stdName:['',[Validators.required, Validators.pattern("^[a-zA-Z ]{3,25}$")]],
//       stdPass:['',[Validators.required, Validators.pattern("^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$")]],
//       confirmstdPass:['',[Validators.required, Validators.pattern("^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$")]],
//       term:['',Validators.requiredTrue],
//       stdEmail:['',[Validators.required, Validators.pattern("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")]],
//       stdContact:['',[Validators.required,Validators.pattern("^[a-zA-Z ]{3,25}$")]]
     
//     })
//   }
 
 
//   confirmPasswordValidator(): ValidatorFn {
//     return (control: AbstractControl): { [key: string]: any } | null => {
//       const confirmStdPass = control.get('confirmStdPass');
//       const stdPass = control.get('stdPass');
 
//       if (confirmStdPass && stdPass && confirmStdPass.value !== stdPass.value) {
//         return { passwordMismatch: true };
//       }
//       return null;
//     };
//   }
 
//   submitData(){
//     console.log(this.studentForm.value);
//   }
 
// }
 
import { Component } from '@angular/core';
import { ReactiveFormsModule, Validators } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FormGroup } from '@angular/forms';
@Component({
  selector: 'app-student-register',
  standalone: true,
  imports: [ReactiveFormsModule,CommonModule],
  templateUrl: './student-register.component.html',
  styleUrl: './student-register.component.css'
})
export class StudentregisterComponent {
  studentForm:any
 
  constructor(private fb:FormBuilder){}
 
  ngOnInit(){
    this.studentForm=this.fb.group({
      stdName:['',[Validators.required,Validators.pattern("^[A-Za-z ]{3,20}$")]],
      stdEmail:['',[Validators.required,Validators.pattern("([A-Za-z0-9]+[.-_])*[A-Za-z0-9]+@[A-Za-z0-9-]+(\.[A-Z|a-z]{2,})+")]],
      stdPass:['',[Validators.required,Validators.pattern("^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$")]],
      confirmstdPass:['',[Validators.required,Validators.pattern("^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$")]],
      term:['',[Validators.requiredTrue]],
      stdContact:['',[Validators.required,Validators.pattern("^[A-Za-z ]{3,20}$")]],
      stdGender:['',[Validators.required,Validators.pattern("^[A-Za-z ]{3,10}$")]]
 
    })
  }
  submitData(){
    console.log(this.studentForm.value)
  }
}
 

